package com.example.villegas.cliente;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextClock;
import android.widget.Toast;

public class interfazCliente extends AppCompatActivity {

    Chronometer crono;
    TextClock hora;
    Button contar, pausa;
    String estado = "inactivo";
    long time=0;
    long memoCronometro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz_cliente);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        crono = (Chronometer) findViewById(R.id.cronometro);
        contar =  (Button) findViewById(R.id.activar);
        pausa = (Button) findViewById(R.id.stop);
        hora = (TextClock) findViewById(R.id.hora_inicial);

        contar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (estado == "inactivo")
                {
                    contar.setEnabled(false);
                    pausa.setEnabled(true);
                    hora.setEnabled(false);
                    crono.setBase(SystemClock.elapsedRealtime());
                    crono.start();
                    estado = "activo";
                    contar.setText("Iniciar");
                    return;
                }
                if (estado=="activo") {
                    memoCronometro = SystemClock.elapsedRealtime();
                    crono.stop();
                    estado = "pausado";
                    contar.setText("Contimuar");
                    return;
                }
                    else
                {
                    crono.setBase(crono.getBase() + SystemClock.elapsedRealtime());
                    crono.start();
                    estado = "activo";
                    contar.setText("Pausar");
                }
            }
        });

        pausa.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                contar.setEnabled(true);
                pausa.setEnabled(false);
                hora.setEnabled(true);
                crono.stop();
                contar.setText("Iniciar");
                estado = "inactivo";
            }
        });
    }


    public void mensajeOnClick(View v)
    {
        Toast.makeText(interfazCliente.this, "Mensaje enviado...", Toast.LENGTH_SHORT).show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_interfaz_cliente, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
